<!DOCTYPE html>
<html lang="en">
<style>
    .JumboHeaderImg {
        background-image: url("assets/img/background77.png");
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
    }
</style>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact us</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>" />
</head>

<body>

    <!-- <header class="jumbotron">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="h1">Contact us</h1>
                </div>
            </div>
        </div>
    </header> -->

    <!-- <div class="container">
        <div class="row">
            <div class="col-md-6">
            
            <form action="" class="form">

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control">
            </div>

            <div class="form-group">
                <label for="email">Message</label>
                <textarea name="message" class="form-control" id="" cols="30" rows="10"></textarea>
            </div>
            
            <div class="form-group">
                <input type="submit" value="Kirim" class="btn btn-primary w-100">
            </div>

            </form>

            </div>
        </div>
    </div> -->

    <div class="jumbotron JumboHeaderImg">
        <div class="container py-3">
            <div class="row" mt-5>
                <div class="col-12 text-center mt-5">
                    <h1>Kontak Admin lpk</h1>
                    <h5>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </h5>
                </div>
            </div>
            <div class="row justify-content-center py-5">
                <div class="col-md-4">
                    <center>
                        <a class=link href="https://api.whatsapp.com/send?phone=6282118032891&text=&source=&data="><img src="assets/img/logowa.png" width=30% height=10% class="img-fluid" alt="Responsive image"></a>
                        <h3 class="pb-4">Whatsapp</h3>
                        <p>+62 82118032891</p>
                        <center>
                </div>
                <div class="col-md-4">
                    <center>
                        <a class=link href="https://www.youtube.com/"><img src="assets/img/logoyb.png" width=30% height=10% class="img-fluid" alt="Responsive image"></a>
                        <h3 class="pb-4">Youtube</h3>
                        <p>lpasksasa</p>
                        <center>
                </div>
                <div class="col-md-4">
                    <center>
                        <a class=link href="https://www.instagram.com/"><img src="assets/img/logoig.png" width=30% height=10% class="img-fluid" alt="Responsive image"></a>
                        <h3 class="pb-4">Instagram</h3>
                        <p>agsjsg</p>
                        <center>
                </div>
                <div class="col-md-4">
                    <center>
                        <a class=link href="https://www.facebook.com/"><img src="assets/img/logofb.png" width=30% height=10% class="img-fluid" alt="Responsive image"></a>
                        <h3 class="pb-4">Facebook</h3>
                        <p>lpk</p>
                        <center>
                </div>

                <div class="col-md-4">
                    <center>
                        <a class=link href="https://mail.google.com/mail/?view=cm&fs=1&to=alwi.n@icloud.com&su=Tanya lpk"><img src="assets/img/logoGM.png" width=30% height=10% class="img-fluid" alt="Responsive image"></a>
                        <h3 class="pb-4">E-Mail</h3>
                        <p>@ashakjsh</p>
                        <center>
                </div>
            </div>



            <!-- Jquery dan Bootsrap JS -->
            <script src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
            <script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>

</body>

</html>